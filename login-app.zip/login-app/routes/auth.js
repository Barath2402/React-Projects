const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// Registration Page
router.get('/register', (req, res) => res.sendFile(__dirname + '/register.html'));

// Register Handle
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    let errors = [];

    if (!username || !password) {
        errors.push({ msg: 'Please enter all fields' });
    }

    if (password.length < 6) {
        errors.push({ msg: 'Password must be at least 6 characters' });
    }

    if (errors.length > 0) {
        res.send(errors);
    } else {
        try {
            let user = await User.findOne({ username: username });
            if (user) {
                res.sendFile(__dirname + '/success.html');
            } else {
                const newUser = new User({
                    username,
                    password
                });

                // Hash password
                bcrypt.genSalt(10, (err, salt) => bcrypt.hash(newUser.password, salt, (err, hash) => {
                    if (err) throw err;
                    newUser.password = hash;
                    newUser.save()
                        .then(user => res.sendFile(__dirname + '/success.html'))
                        .catch(err => console.log(err));
                }));
            }
        } catch (err) {
            console.log(err);
        }
    }
});

// Login Page
router.get('/login', (req, res) => res.sendFile(__dirname + '/login.html'));

// Login Handle
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    let errors = [];

    if (!username || !password) {
        errors.push({ msg: 'Please enter all fields' });
    }

    if (errors.length > 0) {
        res.send(errors);
    } else {
        try {
            let user = await User.findOne({ username: username });
            if (!user) {
                res.sendFile(__dirname + '/incorrect-password.html');
            } else {
                bcrypt.compare(password, user.password, (err, isMatch) => {
                    if (err) throw err;
                    if (isMatch) {
                        res.sendFile(__dirname + '/success.html');
                    } else {
                        res.sendFile(__dirname + '/incorrect-password.html');
                    }
                });
            }
        } catch (err) {
            console.log(err);
        }
    }
});

module.exports = router;
