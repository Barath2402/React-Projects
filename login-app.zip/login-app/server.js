const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
// MongoDB Connection
mongoose.connect('mongodb+srv://webgentechsolutions:pass@cluster0.dpw6ulm.mongodb.net/loginApp', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));
// Routes
app.use('/', require('./routes/auth'));
// Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
